






// Определяем функции для отображения сообщения об ошибке
function printError(elemId, hintMsg) {
    document.getElementById(elemId).innerHTML = hintMsg;
}

// Определяем функции для проверки формы
function validateForm() {
	
    // Получение значений элементов формы
    var phone = document.getElementById('phone').value;
    var password = document.getElementById('password').value;
	
    // Определяем переменные ошибок со значением по умолчанию
    var phoneErr = passwordErr = true;
    
    // Проверяем номер мобильного телефона
    if(phone == "") {
        printError("mobileErr", "Пожалуйста, введите Ваш номер телефона");
    } else {
        var regex = /^[0-9]\d{9}$/;
        if(regex.test(phone) === false) {
            printError("mobileErr", "Пожалуйста, введите действительный 10-значный номер мобильного телефона");
        } else{
            //printError("phoneErr", "");
            phoneErr = false;
        }
    }
	
    if(password == "") {
        printError("passwordErr", "Пожалуйста, введите пароль");
    } else {
        var regex = /^[0-9]\d{10,}$/;
        if(regex.test(password) === false) {
            printError("passwordErr", "Пароль должен быть от 10 символов");
        } else{
            //printError("passwordErr", "");
            passwordErr = false;
        }
    }
	
    // Запрещаем отправку формы в случае ошибок
    if((phoneErr || passwordErr) == true) {
       return false;
    } else {
        // Создаем строки из входных данных для предварительного просмотра
        var dataPreview = "Вы ввели следующие данные: \n" +
                          "Номер телефона: " + phone + "\n" +
                          "Пароль: " + password + "\n";
        // Отображаем входные данные в диалоговом окне перед отправкой формы
        alert(dataPreview);
    }
	
};
